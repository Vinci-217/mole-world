归来的风景 · 三片相连的庄园

浏览器进入 index.html，摩尔城堡、神秘花海和黑森林属于同一个世界。
点击「开始探索」进入步行并开启原版音乐。WASD / 方向键行走，拖动环顾，
Shift 快走，空格轻跳，E 互动，Esc 环绕看风景，M 打开地图，J 旅人手记，P 拍照。
手机使用屏幕方向键和「互动」按钮。顶部可快速抵达三个地区；也能沿小径与石桥步行跨区。
花海浇花、森林点亮三盏灯后触碰树心、城堡推门并敲钟，组成一段会保存在本机的旅程。
右上角可选晴天、薄雾、细雨，以及昼夜和画质；「留下风景」可下载实际三维照片。

Handmade-Manor-Website.zip 是静态网站包。解压后运行：
  python3 -m http.server 8000
然后在浏览器打开 http://localhost:8000。请勿用 file:// 双击 HTML，
模型加载及 SHA-256 校验需要 HTTP 的 localhost 或 HTTPS。
也可以将整个文件夹上传任意 HTTPS 静态托管，支持托管在子目录下。
网页正常运行不需要 Node、Blender、模型 API 或密钥。

Handmade-Manor-Blender.zip 提供八个已经打包贴图的 .blend 工程、原始建模脚本、
纹理与完整来源。Blender 4.3.2 可以直接编辑，不是用截图代替三维模型。
在该源包根目录执行：
  blender -b --python-exit-code 1 --python scripts/build_handmade_world.py
  blender -b --python-exit-code 1 --python scripts/audit_handmade.py
输出位于 public/assets/handmade/，工程位于 artifacts/handmade/。
Three.js 地形、种植布局、水体和交互源代码位于 GitHub 仓库的 src/manor/。

当前版本是重新制作的可玩场景，未声称达到 3A 成品画质或还原所有原版地图。
详细素材许可见 assets/handmade/credits.html（网站）或 public/assets/handmade/credits.html（源包）。
本项目为非官方同人，原版音乐权利归原游戏权利方。
源代码与后续版本：https://github.com/Vinci-217/mole-world
